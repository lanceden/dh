export default {
  MetuItem: 'MetuItem',
  MemberList: 'MemberList',
  AdminList: 'AdminList',
  GetMetuItem: 'GetMetuItem',
  GetMemberList: 'GetMemberList',
  GetMember: 'GetMember',
  GetAdminList: 'GetAdminList',
  GetAdmin: 'GetAdmin',
  GetVipList: 'GetVipList',
  AddVipList: 'AddVipList',
  AuthLogin: 'AuthLogin',
  EditAdmin: 'EditAdmin',
  GetShowLoading: 'GetShowLoading',
  ShowLoading: 'ShowLoading',
  HideLoading: 'HideLoading'
}
