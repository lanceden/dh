export const valMultiplyn = (val, n) => {
  return `${val * n}`
}
