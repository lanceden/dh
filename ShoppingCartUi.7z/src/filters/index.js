import { timeFormat } from './timeFormat.js'
import { valMultiplyn } from './addDollar.js'
import { isEmpty } from './isEmpty'

export default { timeFormat, valMultiplyn, isEmpty }
