export const isEmpty = (val) => {
  return val === null ? '無' : val
}
