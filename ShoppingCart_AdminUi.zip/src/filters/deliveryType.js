// 運送方式
export const deliveryType = (val) => {
  switch (parseInt(val)) {
    case 1: return '宅配'
    case 2: return ''
    case 3: return ''
    case 4: return ''
  }
}
