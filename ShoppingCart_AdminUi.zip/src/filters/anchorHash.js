export const anchorHash = (val) => {
  return `#${val}`
}
