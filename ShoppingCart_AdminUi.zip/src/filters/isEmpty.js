// 是否為空值
export const isEmpty = (val) => {
  return val === null ? '無' : val
}
