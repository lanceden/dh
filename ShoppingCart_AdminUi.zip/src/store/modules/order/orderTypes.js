export default {
  OrderList: 'OrderList',
  OrderDtList: 'OrderDtList',
  OrderAddGet: 'OrderAddGet',
  OrderAddPost: 'OrderAddPost',
  OrderEditGet: 'OrderEditGet',
  OrderEditPut: 'OrderEditPut',
  OrderDelete: 'OrderDelete',
  GetOrderList: 'GetOrderList',
  GetOrderDtList: 'GetOrderDtList',
  GetOrder: 'GetOrder',
  GetOrderdt: 'GetOrderdt',
  GetOrderPageCount: 'GetOrderPageCount',
  OrderdtAddGet: 'OrderdtAddGet',
  OrderdtAddPost: 'OrderdtAddPost',
  OrderdtEditGet: 'OrderdtEditGet',
  OrderdtDelete: 'OrderdtDelete'
}
