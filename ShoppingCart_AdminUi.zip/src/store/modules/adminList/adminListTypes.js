export default {
  AdminAccountList: 'AdminAccountList',
  AdminAccountAddGet: 'AdminAccountAddGet',
  AdminAccountAddPost: 'AdminAccountAddPost',
  AdminAccountEditGet: 'AdminAccountEditGet',
  AdminAccountEditPut: 'AdminAccountEditPut',
  AdminAccountDelete: 'AdminAccountDelete',
  GetAdminAccountList: 'GetAdminAccountList',
  GetAdminAccount: 'GetAdminAccount'
}
