export default {
  MenuItemList: 'MenuItemList',
  GetMenuItem: 'GetMenuItem',
  MenuItem: 'MenuItem'
}
