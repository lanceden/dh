export default {
  AdminGroupList: 'AdminGroupList',
  AdminGroupAddGet: 'AdminGroupAddGet',
  AdminGroupAddPost: 'AdminGroupAddPost',
  AdminGroupEditGet: 'AdminGroupEditGet',
  AdminGroupEditPut: 'AdminGroupEditPut',
  AdminGroupDelete: 'AdminGroupDelete',
  GetAdminGroupList: 'GetAdminGroupList',
  GetAdminGroup: 'GetAdminGroup'
}
