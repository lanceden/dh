export default {
  MetuItem: 'MetuItem',
  MemberList: 'MemberList',
  GetMetuItem: 'GetMetuItem',
  GetMemberList: 'GetMemberList',
  GetMember: 'GetMember',
  GetVipList: 'GetVipList',
  AddVipList: 'AddVipList',
  AuthLogin: 'AuthLogin',
  GetShowLoading: 'GetShowLoading',
  ShowLoading: 'ShowLoading',
  HideLoading: 'HideLoading',
  ShowDiv: 'ShowDiv',
  HideDiv: 'HideDiv',
  GetAuth: 'GetAuth'
}
