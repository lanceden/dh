export default {
  ShowLoading: true,
  isAdd: false,
  antiKey: ''
}
