<template>
</template>
<script>
export default {}
</script>
<style scoped>
.slide-enter,
.slide-leave-to {
  display: none;
  opacity: .3;
}
</style>
